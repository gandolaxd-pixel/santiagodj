import React, { useState } from "react";

// Configuración
const WHATSAPP_NUMBER = "971581258096"; // +971 58 125 8096 (sin +)

const PRODUCTS = [
  { id: 1, name: "Sheikh Al Emarat – Khalis", price: 219, desc: "EDP 100ml • Manzana, neroli, sándalo.", img: "https://images.unsplash.com/photo-1556228720-195a672e8a03?q=80&w=1200&auto=format&fit=crop" },
  { id: 2, name: "Mousuf – Ard Al Zaafaran", price: 199, desc: "EDP 100ml • Dulce ambarado, firma árabe.", img: "https://images.unsplash.com/photo-1530639832026-5a6b1b802c04?q=80&w=1200&auto=format&fit=crop" },
  { id: 3, name: "Ticket – Secret Ocean Yacht Party", price: 450, desc: "Sunset • DJs internacionales • Dubai Marina.", img: "https://images.unsplash.com/photo-1514894780887-121968d00567?q=80&w=1200&auto=format&fit=crop" },
];

const EVENTS = [
  { id: "kaimana", title: "Kaimana Beach – Sunset Afro House", date: "2025-08-15", time: "17:00", location: "Palm Jumeirah", cover: "https://images.unsplash.com/photo-1517957745820-3d4f50f0f4f0?q=80&w=1200&auto=format&fit=crop" },
  { id: "yacht", title: "Secret Ocean Yacht Party", date: "2025-08-22", time: "16:30", location: "Dubai Marina", cover: "https://images.unsplash.com/photo-1533105079780-92b9be482077?q=80&w=1200&auto=format&fit=crop" },
];

const Section = ({ children, className = "" }) => (
  <section className={`max-w-6xl mx-auto px-4 ${className}`}>{children}</section>
);

const Tag = ({ children }) => (
  <span className="inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium">{children}</span>
);

export default function App() {
  const [tab, setTab] = useState("home");
  const [cart, setCart] = useState([]);
  const [form, setForm] = useState({ name: "", email: "", date: "", people: 2, notes: "" });
  const [message, setMessage] = useState("");

  const addToCart = (item) => {
    setCart((c) => {
      const exists = c.find((x) => x.id === item.id);
      if (exists) return c.map((x) => (x.id === item.id ? { ...x, qty: x.qty + 1 } : x));
      return [...c, { ...item, qty: 1 }];
    });
    setMessage(`${item.name} agregado al carrito`);
    setTimeout(() => setMessage(""), 1600);
  };

  const removeFromCart = (id) => setCart((c) => c.filter((x) => x.id !== id));
  const total = cart.reduce((sum, x) => sum + x.price * x.qty, 0);

  const submitBooking = (e) => {
    e.preventDefault();
    // (Futuro) Conectar a backend/Firebase/Airtable
    setMessage("Reserva enviada ✅ – Te contactaremos por email");
    setForm({ name: "", email: "", date: "", people: 2, notes: "" });
    setTimeout(() => setMessage(""), 2200);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-neutral-50 to-neutral-100 text-neutral-900">
      {/* NAVBAR */}
      <header className="sticky top-0 z-20 backdrop-blur supports-[backdrop-filter]:bg-white/60 bg-white/70 border-b">
        <Section className="py-3 flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="inline-grid place-items-center w-9 h-9 rounded-2xl bg-black text-white font-bold">SG</span>
            <div>
              <h1 className="text-base font-semibold leading-tight">SG Events Dubai</h1>
              <p className="text-xs text-neutral-500 -mt-0.5">DJ • Yacht Parties • Fragancias</p>
            </div>
          </div>

          <nav className="ml-auto flex items-center gap-1">
            {[
              { id: "home", label: "Inicio" },
              { id: "events", label: "Eventos" },
              { id: "shop", label: "Tienda" },
              { id: "profile", label: "Perfil" },
              { id: "cart", label: `Carrito (${cart.reduce((n, x) => n + x.qty, 0)})` },
            ].map((b) => (
              <button
                key={b.id}
                onClick={() => setTab(b.id)}
                className={`px-3 py-2 text-sm rounded-xl transition ${tab === b.id ? "bg-black text-white" : "hover:bg-black/5"}`}
              >
                {b.label}
              </button>
            ))}
          </nav>
        </Section>
      </header>

      {/* TOAST */}
      {message && (
        <div className="fixed left-1/2 -translate-x-1/2 top-20 z-30 bg-black text-white text-sm px-4 py-2 rounded-xl shadow-lg">
          {message}
        </div>
      )}

      {/* HOME */}
      {tab === "home" && (
        <main>
          <Section className="py-10 grid md:grid-cols-2 gap-8 items-center">
            <div>
              <div className="inline-flex items-center gap-2 mb-3">
                <Tag>Dubai</Tag>
                <Tag>Afro House</Tag>
                <Tag>Yacht Parties</Tag>
              </div>
              <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight leading-tight">
                Eventos con vibra real: <span className="bg-gradient-to-r from-black to-neutral-500 bg-clip-text text-transparent">música, mar y buen perfume</span>
              </h2>
              <p className="mt-4 text-neutral-600">
                Reserva una fecha, compra tickets o descubre fragancias árabes seleccionadas. Todo en un solo lugar.
              </p>
              <div className="mt-6 flex gap-3">
                <button onClick={() => setTab("events")} className="px-4 py-2 rounded-xl bg-black text-white">Ver eventos</button>
                <button onClick={() => setTab("shop")} className="px-4 py-2 rounded-xl border">Ir a la tienda</button>
              </div>
            </div>
            <div className="aspect-video rounded-2xl overflow-hidden shadow-xl">
              <img
                alt="Sunset party in Dubai"
                src="https://images.unsplash.com/photo-1533105079780-92b9be482077?q=80&w=1200&auto=format&fit=crop"
                className="w-full h-full object-cover"
              />
            </div>
          </Section>

          <Section className="pb-16">
            <h3 className="text-xl font-semibold mb-4">Próximos destacados</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {EVENTS.map((ev) => (
                <article key={ev.id} className="rounded-2xl overflow-hidden bg-white shadow">
                  <img src={ev.cover} alt={ev.title} className="h-40 w-full object-cover" />
                  <div className="p-4">
                    <h4 className="font-bold">{ev.title}</h4>
                    <p className="text-sm text-neutral-600">{ev.date} • {ev.time} • {ev.location}</p>
                    <div className="mt-3 flex gap-2">
                      <button className="px-3 py-2 rounded-xl bg-black text-white text-sm" onClick={() => setTab("events")}>Reservar</button>
                      <button className="px-3 py-2 rounded-xl border text-sm" onClick={() => setTab("shop")}>Comprar ticket</button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </Section>
        </main>
      )}

      {/* EVENTS */}
      {tab === "events" && (
        <Section className="py-10">
          <h2 className="text-2xl font-extrabold mb-6">Reservar un evento</h2>
          <div className="grid md:grid-cols-2 gap-10">
            <form onSubmit={submitBooking} className="bg-white rounded-2xl shadow p-6 space-y-4">
              <div>
                <label className="text-sm font-medium">Nombre completo</label>
                <input className="mt-1 w-full border rounded-xl p-3" required value={form.name} onChange={(e)=>setForm({...form,name:e.target.value})} />
              </div>
              <div>
                <label className="text-sm font-medium">Email</label>
                <input type="email" className="mt-1 w-full border rounded-xl p-3" required value={form.email} onChange={(e)=>setForm({...form,email:e.target.value})} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Fecha</label>
                  <input type="date" className="mt-1 w-full border rounded-xl p-3" required value={form.date} onChange={(e)=>setForm({...form,date:e.target.value})} />
                </div>
                <div>
                  <label className="text-sm font-medium">Personas</label>
                  <input type="number" min={1} className="mt-1 w-full border rounded-xl p-3" value={form.people} onChange={(e)=>setForm({...form,people:Number(e.target.value)})} />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium">Notas</label>
                <textarea className="mt-1 w-full border rounded-xl p-3" rows={4} placeholder="Set Afro House, bailarinas, drummers…" value={form.notes} onChange={(e)=>setForm({...form,notes:e.target.value})}/>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button className="px-4 py-3 rounded-xl bg-black text-white">Enviar reserva</button>
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}?text=Hola%20SG%20Events%20Dubai%2C%20quiero%20cotizar%20un%20evento%20privado%20%F0%9F%8E%B6%F0%9F%8F%84%0AFecha%3A%20_____%0APersonas%3A%20_____%0ALugar%3A%20_____%0ADetalles%3A%20_____`}
                  target="_blank"
                  className="px-4 py-3 rounded-xl border text-center"
                >WhatsApp</a>
              </div>
            </form>

            <div className="space-y-4">
              <h3 className="font-semibold">Próximas fechas</h3>
              <ul className="space-y-3">
                {EVENTS.map((ev) => (
                  <li key={ev.id} className="bg-white rounded-xl p-4 shadow flex items-center gap-4">
                    <img src={ev.cover} alt={ev.title} className="w-24 h-16 object-cover rounded-lg" />
                    <div>
                      <p className="font-medium">{ev.title}</p>
                      <p className="text-sm text-neutral-600">{ev.date} • {ev.time} • {ev.location}</p>
                    </div>
                  </li>
                ))}
              </ul>
              <div className="bg-neutral-900 text-white rounded-2xl p-5">
                <p className="text-sm">¿Evento privado o corporate?</p>
                <p className="text-lg font-bold">Experiencias premium en Dubai y Abu Dhabi</p>
                <div className="mt-3 flex gap-2">
                  <button onClick={()=>setTab("home")} className="px-3 py-2 rounded-xl bg-white text-black">Ver más</button>
                  <a href={`https://wa.me/${WHATSAPP_NUMBER}?text=Hola%20SG%20Events%20Dubai%2C%20quiero%20cotizar%20un%20evento%20privado%20%F0%9F%8E%B6%F0%9F%8F%84%0AFecha%3A%20_____%0APersonas%3A%20_____%0ALugar%3A%20_____%0ADetalles%3A%20_____`} target="_blank" className="px-3 py-2 rounded-xl border bg-white/10">WhatsApp</a>
                </div>
              </div>
            </div>
          </div>
        </Section>
      )}

      {/* SHOP */}
      {tab === "shop" && (
        <Section className="py-10">
          <h2 className="text-2xl font-extrabold mb-6">Tienda</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {PRODUCTS.map((p) => (
              <article key={p.id} className="rounded-2xl overflow-hidden bg-white shadow flex flex-col">
                <img src={p.img} alt={p.name} className="h-44 w-full object-cover" />
                <div className="p-4 flex-1 flex flex-col">
                  <h4 className="font-bold">{p.name}</h4>
                  <p className="text-sm text-neutral-600 flex-1">{p.desc}</p>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="font-semibold">AED {p.price}</span>
                    <button className="px-3 py-2 rounded-xl bg-black text-white text-sm" onClick={() => addToCart(p)}>Agregar</button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </Section>
      )}

      {/* CART */}
      {tab === "cart" && (
        <Section className="py-10">
          <h2 className="text-2xl font-extrabold mb-6">Carrito</h2>
          {cart.length === 0 ? (
            <p className="text-neutral-600">Tu carrito está vacío. Agrega productos en la <button className="underline" onClick={()=>setTab("shop")}>tienda</button>.</p>
          ) : (
            <div className="grid md:grid-cols-3 gap-8">
              <div className="md:col-span-2 space-y-3">
                {cart.map((x) => (
                  <div key={x.id} className="bg-white rounded-xl p-4 shadow flex items-center gap-4">
                    <img src={x.img} alt={x.name} className="w-24 h-16 object-cover rounded-lg" />
                    <div className="flex-1">
                      <p className="font-medium">{x.name}</p>
                      <p className="text-sm text-neutral-600">AED {x.price} • Cantidad: {x.qty}</p>
                    </div>
                    <button className="text-sm underline" onClick={() => removeFromCart(x.id)}>Quitar</button>
                  </div>
                ))}
              </div>
              <div className="bg-white rounded-xl p-5 shadow">
                <p className="font-semibold">Resumen</p>
                <p className="flex justify-between mt-2"><span>Subtotal</span><span>AED {total.toFixed(2)}</span></p>
                <p className="flex justify-between text-sm text-neutral-600"><span>Envío</span><span>Se calcula al finalizar</span></p>
                <button className="mt-4 w-full px-4 py-3 rounded-xl bg-black text-white">Pagar (demo)</button>
                <p className="text-xs text-neutral-500 mt-2">* Integra Stripe / PayPal aquí</p>
              </div>
            </div>
          )}
        </Section>
      )}

      {/* PROFILE */}
      {tab === "profile" && (
        <Section className="py-10">
          <h2 className="text-2xl font-extrabold mb-6">Perfil</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2 bg-white rounded-2xl p-6 shadow">
              <p className="text-sm text-neutral-600">Este es un perfil de ejemplo. Aquí puedes mostrar tu bio, riders técnicos, press kit y enlaces.</p>
              <ul className="mt-4 space-y-2 text-sm list-disc pl-6">
                <li>Bio: DJ profesional en Dubái, especialista en Afro House con toques comerciales.</li>
                <li>Rider: CDJ-3000 x2, DJM-900NXS2, monitores KRK.</li>
                <li>Prensa: Links a Instagram, TikTok, SoundCloud.</li>
              </ul>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow">
              <p className="font-semibold">Contacto directo</p>
              <p className="text-sm text-neutral-600">Email: booking@sgdubai.ae</p>
              <div className="mt-3 grid gap-2">
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}?text=Hola%20SG%20Events%20Dubai%2C%20quiero%20reservar%20%F0%9F%8E%B6%0AFecha%3A%20_____%0APersonas%3A%20_____`}
                  target="_blank"
                  className="w-full text-center px-4 py-2 rounded-xl border"
                >
                  Contactar por WhatsApp
                </a>
                <button className="w-full px-4 py-2 rounded-xl bg-black text-white">Enviar mensaje</button>
                <p className="text-[11px] text-neutral-500">* El botón abre chat a WhatsApp con tu número.</p>
              </div>
            </div>
          </div>
        </Section>
      )}

      <footer className="py-10 text-center text-xs text-neutral-500">
        Hecho con ❤️ – MVP listo para crecer (React + Tailwind). Añade backend cuando quieras.
      </footer>
    </div>
  );
}
